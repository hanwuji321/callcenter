$(function(){
	width=$(window).width();
	height=$(window).height();
	newheight=height-52;
    $('#call_center').css({'width':width,'height':height}) 
    $('#callcontent').css({'height':newheight})
	$(window).resize(function(){
		width=$(window).width();
		height=$(window).height();
		newheight=height-52;
        $('#call_center').css({'width':width,'height':height}) 
        $('#callcontent').css({'height':newheight})
       });

	$('#navebarleftdiv').click(function(){
		$('#navebarleftdu').css('display','block');
	})
	$('#navebarleftdiv').mouseleave(function(){
		$('#navebarleftdu').css('display','none');
	})
	$('#navebarleftzm').click(function(){
		$('#navebarleftzx').html('<img src="images/dot.png" style="width:20px;"> 置忙');
		$('#botphone').html('正在通话');
		$('#botphonetime').html('24:00:00')
		$('#navebarright1').css('display','none');
		$('#navebarright2').css('display','block');
	})
	$('#navebarleftzxi').click(function(){
		$('#navebarleftzx').html('<img src="images/smile.png" style="width:13px;"> 置闲');
		$('#botphone').html('准备外呼');
		$('#botphonetime').html('00:00:00')
		$('#navebarright1').css('display','block');
		$('#navebarright2').css('display','none');
		
	})

	$('#clickbtn').click(function(){
		event.preventDefault(); 
		$('#clickul').css('display','block')
	})
	$('#clickbtn').mouseleave(function(){
		
		$('#clickul').css('display','none')
	})
})

$(function(){
    $('.tabs').tabulous({
        effect: 'scale'
    });
});

// 日期选择


		function DatePicker(beginSelector,endSelector){
            // 仅选择日期
            $(beginSelector).datepicker(
            {
            	language:  "zh-CN",
            	autoclose: true,
            	startView: 0,
            	format: "yyyy-mm-dd",
            	clearBtn:true,
            	todayBtn:false,
            	endDate:new Date()
            }).on('changeDate', function(ev){
            	if(ev.date){
            		$(endSelector).datepicker('setStartDate', new Date(ev.date.valueOf()))
            	}else{
            		$(endSelector).datepicker('setStartDate',null);
            	}
            })

            $(endSelector).datepicker(
            {
            	language:  "zh-CN",
            	autoclose: true,
            	startView:0,
            	format: "yyyy-mm-dd",
            	clearBtn:true,
            	todayBtn:false,
            	endDate:new Date()
            }).on('changeDate', function(ev){  
            	if(ev.date){
            		$(beginSelector).datepicker('setEndDate', new Date(ev.date.valueOf()))
            	}else{
            		$(beginSelector).datepicker('setEndDate',new Date());
            	} 

            })
        }

        DatePicker("#date_begin","#date_end");


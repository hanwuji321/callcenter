// 搜索联系人
  var data = [{
    key: '1',
    name: '杨志刚1',
    phone:+8612356595,
    company: '北京神州云动科技股份有限公司1',
    num: '1',
    time: '13:51:24',
    job:'项目经理',
    bumen:'产品部门',
  }, {
    key: '2',
    name: '杨志刚2',
    phone:+8612356595,
    company: '北京神州云动科技股份有限公司2',
    num: '2',
    time: '13:51:24',
    job:'项目经理',
    bumen:'产品部门',
  }, {
    key: '3',
    name: '杨志刚3',
    phone:+8612356595,
    company: '北京神州云动科技股份有限公司3',
    num: '3',
    time: '13:51:24',
    job:'项目经理',
    bumen:'产品部门',
  }, {
    key: '4',
    name: '杨志刚4',
    phone:+8612356595,
    company: '北京神州云动科技股份有限公司4',
    num: '4',
    time: '13:51:24',
    job:'项目经理',
    bumen:'产品部门',
  }, {
    key: '5',
    name: '杨志刚5',
    phone:+8612356595,
    company: '北京神州云动科技股份有限公司5',
    num: '5',
    time: '13:51:24',
    job:'项目经理',
    bumen:'产品部门',
  }, {
    key: '2',
    name: '杨志刚2',
    phone:+8612356595,
    company: '北京神州云动科技股份有限公司2',
    num: '2',
    time: '13:51:24',
    job:'项目经理',
    bumen:'产品部门',
  }, {
    key: '3',
    name: '杨志刚3',
    phone:+8612356595,
    company: '北京神州云动科技股份有限公司3',
    num: '3',
    time: '13:51:24',
    job:'项目经理',
    bumen:'产品部门',
  }, {
    key: '4',
    name: '杨志刚4',
    phone:+8612356595,
    company: '北京神州云动科技股份有限公司4',
    num: '4',
    time: '13:51:24',
    job:'项目经理',
    bumen:'产品部门',
  }, {
    key: '5',
    name: '杨志刚5',
    phone:+8612356595,
    company: '北京神州云动科技股份有限公司5',
    num: '5',
    time: '13:51:24',
    job:'项目经理',
    bumen:'产品部门',
  }];

  var ndata=eval(data);
  var html="";
  for(var x=0;x<ndata.length;x++){
  html+='<li><p>'+ndata[x].name+'<span class="glyphicon glyphicon-user iconfright" style="color:#0ACCE7;"></span></p><p>'+ndata[x].company+'</p><p><span>'+ndata[x].bumen+'</span>&nbsp; &nbsp;  <span>'+ndata[x].job+'</span></p><p><span class="glyphicon glyphicon-earphone" style="color:#67D694;"></span> <span>'+ndata[x].phone+'</span> <span class="spanfright"><span class="glyphicon glyphicon-earphone" style="color:#67D694;"></span> '+ndata[x].phone+'</span></p></li>';

  }
  console.log(html)
  $("#linkmanul").html(html);

// 最近通话
  var RecentCalls = [{
    key: '1',
    name: '杨志刚1',
    phone:'+8612356595',
    tel:'010-8234-5762',
    company: '北京神州云动科技股份有限公司1',
    num: '1',
    icon:'phone',
    bum:'',
    time: '13:51:24',
    job:'项目经理',
    sign:'user',
  }, {
    key: '2',
    name: '杨志刚2',
    phone:'+8612356595',
    tel:'',
    icon:'',
    company: '北京神州云动科技股份有限公司2',
    num: '2',
    bum:'',
    time: '13:51:24',
    job:'项目经理',
    sign:'team',
  }, {
    key: '3',
    name: '杨志刚3',
    phone:'+8612356595',
    tel:'010-8234-5762',
    icon:'phone',
    company: '北京神州云动科技股份有限公司3',
    num: '3',
    bum:'产品部门',
    time: '13:51:24',
    job:'项目经理',
    sign:'team',
  }, {
    key: '4',
    name: '杨志刚4',
    phone:'+8612356595',
    tel:'010-8234-5762',
    icon:'phone',
    company: '北京神州云动科技股份有限公司4',
    num: '4',
    bum:'产品部门',
    time: '13:51:24',
    job:'项目经理',
    sign:'user',
  }, {
    key: '5',
    name: '杨志刚5',
    phone:'+8612356595',
    tel:'010-8234-5762',
    icon:'phone',
    company: '北京神州云动科技股份有限公司5',
    num: '5',
    bum:'产品部门',
    time: '13:51:24',
    job:'项目经理',
    sign:'team',
  }, {
    key: '2',
    name: '杨志刚2',
    phone:'+8612356595',
    tel:'010-8234-5762',
    icon:'phone',
    company: '北京神州云动科技股份有限公司2',
    num: '2',
    bum:'产品部门',
    time: '13:51:24',
    job:'项目经理',
    sign:'user',
  }, {
    key: '3',
    name: '杨志刚3',
    phone:'+8612356595',
    tel:'010-8234-5762',
    icon:'phone',
    company: '北京神州云动科技股份有限公司3',
    num: '3',
    bum:'产品部门',
    time: '13:51:24',
    job:'项目经理',
    sign:'user',
  }, {
    key: '4',
    name: '杨志刚4',
    phone:'+8612356595',
    tel:'010-8234-5762',
    icon:'phone',
    company: '北京神州云动科技股份有限公司4',
    num: '4',
    bum:'产品部门',
    time: '13:51:24',
    job:'项目经理',
    sign:'user',
  }, {
    key: '5',
    name: '杨志刚5',
    phone:'+8612356595',
    tel:'010-8234-5762',
    icon:'phone',
    company: '北京神州云动科技股份有限公司5',
    num: '5',
    bum:'产品部门',
    time: '13:51:24',
    job:'项目经理',
    sign:'user',
  }];
  var RecentCalls=eval(RecentCalls);
  var RecentCallshtml="";
  for(var i=0;i<RecentCalls.length;i++){
    RecentCallshtml+='<li><i><span class="glyphicon glyphicon-phone-alt"></span></i><p class="linkmanup">'+RecentCalls[i].company+'</p><p><span>'+RecentCalls[i].name+'</span><span>'+RecentCalls[i].phone+'</span>（<span>'+RecentCalls[i].num+'</span>）<span>'+RecentCalls[i].time+'</span></p></li>';
  }
  $("#linkmanu").html(RecentCallshtml);

  // <li>
  //    <i><span class="glyphicon glyphicon-phone-alt"></span></i>
  //    <p class="linkmanup">北京神州云动科技股份有限公司</p>
  //    <p>
  //      <span>杨志刚</span>
  //      <span>+8613523524394</span>
  //      （<span>15</span>）
  //      <span>10：30</span>
  //    </p>
  //  </li>
  
// 联系人列表
  var data2 = [{
    key: '1',
    name: '杨志刚1',
    phone:'+8612356595',
    tel:'010-8234-5762',
    gender:'男',
    work:'项目经理',
    company: '北京神州云动科技股份有限公司1',
  }, {
    key: '2',
    name: '肖静静',
    phone:'+8613425467895',
    tel:'010-8234-5762',
    gender:'女',
    work:'运营管理中心副总经理',
    company: '北京神州云动科技股份有限公司1',
  }, {
    key: '3',
    name: '杨志刚3',
    phone:'+8612356595',
    tel:'010-8234-5762',
    gender:'男',
    work:'项目经理',
    company: '北京神州云动科技股份有限公司1',
  }];

  var data2=eval(data2);
  var listhtml="";
  for(var i=0;i<data2.length;i++){
    listhtml+='<tr><td>'+data2[i].name+'</td><td>'+data2[i].gender+'</td><td>'+data2[i].work+'</td><td><span class="glyphicon glyphicon-earphone" style="color:#67D694;"></span> '+data2[i].phone+'</td><td><span class="glyphicon glyphicon-earphone" style="color:#67D694;"></span> '+data2[i].tel+'</td></tr>';
  }
  console.log(listhtml);
  $('#link_man').html(listhtml);

// Case
  var data3 = [{
    key: '1',
    case:'201706001',
    theme:'电脑屏幕闪屏',
    credate:'2017/6/17',
    record:'咨询',
    types:'功能咨询',
    status:'新建',
    priority:'高',
  }, {
    key: '2',
    case:'201706001',
    theme:'如何启用蓝牙功能',
    credate:'2017/6/17',
    record:'投诉',
    types:'问题',
    status:'新建',
    priority:'高',
  }, {
    key: '3',
    case:'201706001',
    theme:'电脑屏幕闪屏',
    credate:'2017/6/17',
    record:'咨询',
    types:'功能咨询',
    status:'关闭',
    priority:'高',
  }, {
    key: '4',
    case:'201706001',
    theme:'如何启用蓝牙功能',
    credate:'2017/6/17',
    record:'咨询',
    types:'功能咨询',
    status:'关闭',
    priority:'高',
  }, {
    key: '4',
    case:'201706001',
    theme:'如何启用蓝牙功能',
    credate:'2017/6/17',
    record:'咨询',
    types:'功能咨询',
    status:'关闭',
    priority:'高',
  }];

  var data3=eval(data3);
  var itemhtml="";
  for(var i=0;i<data3.length;i++){
    itemhtml+='<tr><td>'+data3[i].case+'</td><td>'+data3[i].theme+'</td><td>'+data3[i].credate+'</td><td>'+data3[i].record+'</td><td>'+data3[i].types+'</td><td>'+data3[i].status+'</td><td>'+data3[i].priority+'</td></tr>';
  }
  console.log(itemhtml);
  $('#rlistitem').html(itemhtml);
  $('#rlistitem2').html(itemhtml);
  $('#rlistitem3').html(itemhtml);
  $('#rlistitem4').html(itemhtml);

  // '<tr>
  //   <td>'+data3[i].case+'</td>
  //   <td>'+data3[i].theme+'</td>
  //   <td>'+data3[i].credate+'</td>
  //   <td>'+data3[i].record+'</td>
  //   <td>'+data3[i].types+'</td>
  //   <td>'+data3[i].status+'</td>
  //   <td>'+data3[i].priority+'</td>
  // </tr>'
